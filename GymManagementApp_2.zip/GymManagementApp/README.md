﻿# Projekt zaliczeniowy z ASP .NET
### Techniki Internetowe, IiE 22/23

Projekt o strukturze Model-View-Controller, oparty na platformie .NET oraz EntityFramework. Posiada cztery modele, na których można przeprowadzać operacje CRUD.

## Instalowanie projektu na maszynie lokalnej
1. Sklonuj repozytorium w programie Visual Studio 2022.
2. W konsoli menadżera pakietów wpisz i zatwierdź:
- `Enable-Migrations`
- `add-migration First -Force`
- `update-database`
3. Projekt jest gotowy do użycia na maszynie lokalnej.
