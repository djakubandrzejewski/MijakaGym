﻿## Cel projektu: 

Celem projektu jest stworzenie aplikacji webowej opartej na platformie .NET, z wykorzystaniem EntityFramework, która umożliwi efektywne zarządzanie siłownią. Pozwoli on też na wykorzystanie nabytych do tej pory umiejętności i na sprawdzenie się w pracy grupowej nad dużym projektem. Sama aplikacja ma na celu ułatwienie procesu rejestracji użytkowników, zarządzania trenerami, przypisywania ich do odpowiednich grup oraz monitorowania karnetów.

## Zastosowanie biznesowe: 

Aplikacja do zarządzania siłownią ma na celu zautomatyzowanie wielu procesów, które są nieodłączne w codziennym funkcjonowaniu takiego przedsiębiorstwa. Oto główne obszary zastosowania biznesowego aplikacji:

1.	Rejestracja użytkowników: Aplikacja umożliwia łatwą i szybką rejestrację nowych użytkowników siłowni. Wystarczy wypełnić formularz rejestracyjny, podając niezbędne dane osobowe i preferencje dotyczące treningów. Dane te są przechowywane w bazie danych, co nie tylko pozwala zachowywać ich dane, łączyć z karnetami i przypisywać do odpowiednich grup ćwiczeniowych, ale daje też możliwość przeprowadzenia późniejszych analiz oraz personalizacji oferty siłowni dla klientów.
2.	Zarządzanie trenerami: Aplikacja umożliwia zarządzanie danymi trenerów pracujących w siłowni. Można dodawać nowych trenerów, edytować istniejące dane, a także przypisywać ich do odpowiednich grup treningowych. Dzięki temu właściciel siłowni może skutecznie zarządzać zespołem trenerów, ustalać grafiki zajęć oraz kontrolować obecność i wydajność trenerów.
3.	Przypisywanie użytkowników do grup treningowych: Aplikacja umożliwia przypisywanie użytkowników do odpowiednich grup treningowych. Dzięki temu można zoptymalizować zajęcia, tworząc grupy o podobnym poziomie umiejętności lub preferencjach treningowych. Użytkownicy zyskują dostęp do spersonalizowanych zajęć, a siłownia może efektywniej wykorzystać zasoby treningowe.
4.	Zarządzanie karnetami: Aplikacja umożliwia kompleksowe zarządzanie karnetami użytkowników. Można dodawać nowe karnety a także zmieniać status ważności istniejących. Dzięki temu właściciel siłowni ma pełną kontrolę nad procesem opłat, terminowością karnetów oraz dostępem użytkowników do usług siłowni.

## Baza danych

![database diagram](../Content/custom/images/diagram.png)

Nasza baza danych zawiera cztery tabele:
- Users
- Groups
- Coaches
- Memberships.
####
Pomiędzy nimi występują trzy relacje:
- Pomiędzy Coach a Group relacja jeden do wielu. Każdy trener może mieć pod opieką wiele grup, ale każda grupa tylko jednego trenera.
- Pomiędzy Group a User relacja wiele do wielu. Każdy użytkownik może być zapisany do wielu grup, tak samo jak każda grupa może zawierać wielu różnych użytkowników.
- Pomiędzy User a Membership relacja jeden do wielu. Każdy użytkownik może mieć kilka karnetów, na wypadek gdy jeden z nich wygasa lub użytkownik chce zmienić typ karnetu. Karnet natomiast może być przypisany tylko do jednego użytkownika.

Przechowują one dane, które wymagane są do obsługi aplikacji.
Z wykorzystaniem EntityFramework, na podstawie SQL-owej bazy danych, tworzy się modele odpowiedzialne za obsługiwanie bazy w aplikacji. 

## Opis modeli

### EntityModels - modele bazy danych

1. CoachEntity - model odpowiadający za przechowywanie trenerów. Zawiera następujące pola:
    - CoachID - ID nadawane trenerom podczas tworzenia rekordu,
    - Name - imię trenera,
    - Surname - nazwisko trenera,
    - Email - email trenera,
    - Specialty - dziedzina, w której trener się specjalizuje. Do wyboru mamy jogę, kalistenikę i trójbój.
2. GroupEntity - model odpowiadający za przechowywanie grup treningowych. Zawiera pola:
    - GroupID - ID grupy, nadawane podczas tworzenia rekordu,
    - Name - nazwa grupy,
    - CoachID - ID trenera, który prowadzi daną grupę,
    - Users - lista użytkowników zapisanych do grupy,
3. MembershipEntity - model odpowiadający za karnety użytkowników. Zawiera:
    - MembershipID - ID karnetu,
    - MembershipType - rodzaj karnetu. Do wyboru mamy junior, standard i premium,
    - Active - właściwość określająca czy dany karnet jest aktywny czy też nie,
    - UserID - ID użytkownika, do którego należy dany karnet.
4. UserEntity - model odpowiadający za użytkowników. W jego skład wchodzą:
    - UserID - ID nadawane przy tworzeniu nowego użytkownika,
    - Name - imię użytkownika,
    - Surname - nazwisko użytkownika,
    - Email - email użytkownika,
    - BirthDate - data urodzenia użytkownika.
    - Model zawiera też odwołania do karnetów i grup, z którymi użytkownik jest połączony. 

### ViewModels

Aplikacja wykorzystuje też odpowiadające powyższym modelom ViewModels do przedstawiania danych. Wykorzystuje się je, aby odizolować warstwę bazodanową od użytkowników aplikacji. Można też z ich pomocą tworzyć dodatkowe widoki m.in. agregujące dane, bez niepotrzebnego zapisywania ich w bazie danych. 

## Opis kontrolerów i widoków:

### HomeController:

Kontroler odpowiadający za stronę główną aplikacji. Pozwala obsłużyć trzy widoki:
1. Index: akcja odpowiadająca za obsługę żądania dla strony głównej aplikacji, zwracającego stronę startową.
2. About: akcja odpowiadająca za wyświetlenie sekcji "About GMA".
3. Documentation: akcja odpowiadająca za wyświetlenie sekcji, w której znajduje się dokumentacja w języku angielskim oraz link do pobrania dokumentacji w języku polskim.

### Home Views:

Widoki obsługiwane przez powyższy kontroler:
1. Index: widok odpowiadający za stronę startową aplikacji.
2. About: widok odpowiadający za wyświetlenie garści informacji o aplikacji oraz instrukcji obsługi.
3. Documentation: widok odpowiadający za sekcję, w której znajduje się dostępna dokumentacja w dwóch językach.

### GroupsController:

Kontroler odpowiadający za obsługę akcji powiązanych z grupami ćwiczeniowymi:
1. Index: akcja odpowiadająca za wyświetlenie ogólnej strony dla grup.
2. Details: akcja odpowiadająca za wyświetlenie szczegółowych informacji o wybranej grupie.
3. Create: akcje odpowiedzialne za wyświetlenie okna pozwalającego na dodanie grupy oraz na przekazanie jej do bazy.
4. Edit: akcje odpowiedzialne za wyświetlenie okna edycji istniejącej grupy oraz przekazanie zmian.
5. Delete i DeleteConfirmed: akcje odpowiadająca za usuwanie istniejących grup.
6. AddUsers i GroupUsers: akcje odpowiedzialne za wyświetlanie przypisanych do grupy użytkowników oraz przypisywanie nowych członków.

### Groups Views:

Widoki obsługiwane przez powyższy kontroler, powiązane z grupami:
1. Index: widok odpowiadający za stronę, na której wyświetlone są wszystkie istniejące grupy oraz przyciski odnoszące się do innych powyższych akcji.
2. Details: widok odpowiedzialny za wyświetlenie informacji o wybranej grupie.
3. Create: widok odpowiedzialny za tworzenie nowych grup, gdzie można nadać nazwę oraz wybrać trenera.
4. Edit: widok odpowiadający za edycję grup, zawierający wszystkie możliwe do edycji atrybuty grupy.
5. Delete: widok odpowiadający za usuwanie wybranej grupy, razem z potwierdzeniem że na pewno chcemy to zrobić.
6. AddUsers: widok odpowiadający za przypisywanie użytkowników do wybranej grupy.

### CoachesController:

Kontroler odpowiadający za obsługę akcji powiązanych z trenerami:
1. Index: akcja odpowiadająca za wyświetlenie ogólnej strony dla trenerów.
2. Details: akcja odpowiadająca za wyświetlenie szczegółowych informacji o wybranym trenerze.
3. Create: akcje odpowiedzialne za wyświetlenie okna pozwalającego na dodanie trenera oraz na przekazanie go do bazy.
4. Edit: akcje odpowiedzialne za wyświetlenie okna edycji istniejących trenerów oraz przekazanie zmian.
5. Delete i DeleteConfirmed: akcje odpowiadająca za usuwanie istniejących trenerów.

### Coaches Views:

Widoki obsługiwane przez powyższy kontroler, powiązane z trenerami:
1. Index: widok odpowiadający za stronę, na której wyświetleni są wszyscy istniejący trenerzy oraz przyciski odnoszące się do innych powyższych akcji.
2. Details: widok odpowiedzialny za wyświetlenie informacji o wybranym trenerze.
3. Create: widok odpowiedzialny za dodawanie nowych trenerów, gdzie można wprowadzić wymagane dane o trenerze.
4. Edit: widok odpowiadający za edycję wprowadzonych wcześniej trenerów, zawierający wszystkie możliwe do edycji atrybuty.
5. Delete: widok odpowiadający za usuwanie wybranego trenera, razem z potwierdzeniem że na pewno chcemy to zrobić.

### MembershipsController:

Kontroler odpowiadający za akcje związane z karnetami. Są one analogiczne jak w przypadku powyższego CoachesController, z tą różnicą że odnoszą się do karnetów.

### Memberships Views:

Widoki obsługiwane przez MembershipsController. Są analogiczne jak powyższe Coaches Views, jednak odnoszą się do karnetów.

### UsersController: 

Kontroler odpowiadający za akcje związane z użytkownika siłowni. Również jest zbudowany analogicznie do dwóch powyższych, z tym, że odnosi się do użytkowników.

### Users Views

Widoki obsługiwane przez powyższy kontroler związane z użytkownikami. W skład wchodzą analogiczne widoki jak powyżej.

### DocumentationController:

Kontroler odpowiadający jedynie za jedną akcję, którą jest pobranie dokumentacji po naciśnięciu przycisku.

## Dostęp do widoków:

Do konkretnych stron możemy dostać się poprzez naciśnięcie odpowiednich przycisków, lub też wpisując w oknie przeglądarki widok który nas interesuje. Na przykład w przypadku gdy chcemu dodać użytkownika, dopisujemy w przeglądarce "/Users/Create". Analogicznie możemy dostać się do wszystkich stron dostępnych w aplikacji.

Autorzy: Jakub Zięba, Maciej Komosa