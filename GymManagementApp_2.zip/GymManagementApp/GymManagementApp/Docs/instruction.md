# Instrukcja obsługi aplikacji

Witaj w GMA, najlepszej aplikacji do zarządzania siłownią! <br>
Abyś nie musiał martwić się o jakiekolwiek problemy z obsługą aplikacji przygotowaliśmy tę instrukcję.

## Strona startowa
![landing page](../Content/custom/images/start.png)

Jak możesz zauważyć, na stronie startowej znajduje się osiem przycisków, pogrupowanych według czterech kategorii. Są to kolejno: Users, Coaches, Groups and Memberships. Pierwsza z nich odpowiada za użytkowników siłowni, druga za trenerów, trzecia za grupy ćwiczeniowe a czwarta za karnety dostępne na siłowni.
Każda kategoria zawiera dwa przyciski: "Display" i "Create". Do nich przejdziemy później. W górnej części strony znajduje się pasek nawigacyjny z trzema odnośnikami. "Home" odpowiada za sprowadzenie nas z powrotem do strony głównej. "About GMA" to dokładnie to miejsce, z którego dostałeś się do tej instrukcji! "Docs" pozwala dostać się do dokumentacji aplikacji w dwóch językach.

## Users

Przejdźmy teraz do pierwszej kategorii. Klikając "Display" przejdziemy do kolejnej strony.

![users main page](../Content/custom/images/usersindex.png)

Tutaj ukaże nam się lista wszystkich zarejestrowanych użytkowników. Możemy następnie dodać nowego użytkownika przez naciśnięcie "Create New", edytować dane istniejącego użytkownika poprzez "Edit", zobaczyć szczegółowe informacje o użytkowniku pod przyciskiem "Details" lub wyrejestrować go naciskając przycisk "Delete". W górnej części strony znajduje się taki sam pasek nawigacyjny jak wcześniej i będzie on obecny na każdej innej stronie. Aby zarejestrować użytkownika należy podać jego imię, nazwisko, email i datę urodzenia.

![create user page](../Content/custom/images/userscreate.png)

Edytowanie danych wygląda analogicznie.

Jeśli chcemy usunąć użytkownika, program zapyta ponownie czy jesteśmy tego pewni. Po ponownym naciśnięciu "Delete" użytkownik zostanie usunięty.

![delete user page](../Content/custom/images/usersdelete.png)

## Coaches

Kolejną kategorią są trenerzy. Tutaj wszystko odbywa się analogicznie jak w przypadku użytkowników. Jedyną różnicą jest obecność innych cech. Przy rejestrowaniu nowego trenera nie trzeba podawać jego daty urodzenia, wymagany jest jednak wybór specjalizacji. Nie ma z tym jednak żadnego problemu, ponieważ lista specjalizacji jest odgórnie ustalona.

![create coach page](../Content/custom/images/coachescreate.png)

## Memberships

Ta zakładka w zasadzie nie różni się niczym od dwóch poprzednich. Tutaj również możemy dodawać i usuwać karnety, edytować te już istniejące i sprawdzać detale. 

![memberships main page](../Content/custom/images/membershipsindex.png)

## Groups 

Po wejściu w kategorię "Groups" ukaże nam się strona wyświetlająca wszystkie grupy ćwiczeniowe. 

![groups main page](../Content/custom/images/groupsindex.png)

Stąd, podobnie jak w poprzednich sekcjach, możemy przejść do tworzenia nowych grup, edytowania istniejących, sprawdzania detali i usuwania. Nowością natomiast jest przycisk "Users". Odsyła nas on do strony, na której możemy zarządzać użytkownikami przypisanymi do danej grupy ćwiczeniowej.

To już wszystko, co musisz wiedzieć o naszej aplikacji! Miłego użytkowania!