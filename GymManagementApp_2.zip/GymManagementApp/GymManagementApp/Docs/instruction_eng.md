﻿# User Manual for the Application

Welcome to GMA, the best gym management application! <br>
To ensure you have a seamless experience using the application, we have prepared this user manual.

## Home Page
![landing page](../Content/custom/images/start.png)

As you can see, the home page consists of eight buttons grouped into four categories: Users, Coaches, Groups, and Memberships. The first category is for gym members, the second is for coaches, the third is for exercise groups, and the fourth is for gym memberships.
Each category has two buttons: "Display" and "Create." We will discuss them later. At the top of the page, there is a navigation bar with three links. "Home" takes you back to the main page. "About GMA" is where you accessed this user manual! "Docs" provides access to the application's documentation in two languages.

## Users

PLet's now move to the first category. By clicking "Display," we will navigate to the next page.

![users main page](../Content/custom/images/usersindex.png)

Here, you will see a list of all registered users. You can add a new user by clicking "Create New," edit the details of an existing user using "Edit," view detailed information about a user by clicking "Details," or unregister a user by pressing the "Delete" button. The navigation bar at the top of the page remains the same as before and will be present on every other page. To register a user, you need to provide their first name, last name, email, and date of birth.

![create user page](../Content/custom/images/userscreate.png)

Editing user data follows a similar process.

If you want to delete a user, the program will prompt you to confirm your action. After confirming and clicking "Delete" again, the user will be removed.

![delete user page](../Content/custom/images/usersdelete.png)

## Coaches

The next category is for coaches. Here, the process is similar to that of users, with the only difference being the presence of additional attributes. When registering a new coach, you don't need to provide their date of birth, but you must select their specialization. However, there is no problem with that, as the list of specializations is predefined.

![create coach page](../Content/custom/images/coachescreate.png)

## Memberships

This tab is essentially similar to the previous two. Here, you can add and remove memberships, edit existing ones, and check their details.

![memberships main page](../Content/custom/images/membershipsindex.png)

## Groups 

Upon entering the "Groups" category, you will see a page displaying all exercise groups.

![groups main page](../Content/custom/images/groupsindex.png)

Similar to the previous sections, you can create new groups, edit existing ones, check details, and delete them. The new addition here is the "Users" button. It redirects you to a page where you can manage the users assigned to a specific exercise group.

That's all you need to know about our application! Enjoy using it!