﻿namespace GymManagementApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class First1 : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Coaches", newName: "CoachEntities");
            RenameTable(name: "dbo.Groups", newName: "GroupEntities");
            RenameTable(name: "dbo.Users", newName: "UserEntities");
            RenameTable(name: "dbo.Memberships", newName: "MembershipEntities");
            RenameTable(name: "dbo.UserGroups", newName: "UserEntityGroupEntities");
            RenameColumn(table: "dbo.UserEntityGroupEntities", name: "User_UserID", newName: "UserEntity_UserID");
            RenameColumn(table: "dbo.UserEntityGroupEntities", name: "Group_GroupID", newName: "GroupEntity_GroupID");
            RenameIndex(table: "dbo.UserEntityGroupEntities", name: "IX_User_UserID", newName: "IX_UserEntity_UserID");
            RenameIndex(table: "dbo.UserEntityGroupEntities", name: "IX_Group_GroupID", newName: "IX_GroupEntity_GroupID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.UserEntityGroupEntities", name: "IX_GroupEntity_GroupID", newName: "IX_Group_GroupID");
            RenameIndex(table: "dbo.UserEntityGroupEntities", name: "IX_UserEntity_UserID", newName: "IX_User_UserID");
            RenameColumn(table: "dbo.UserEntityGroupEntities", name: "GroupEntity_GroupID", newName: "Group_GroupID");
            RenameColumn(table: "dbo.UserEntityGroupEntities", name: "UserEntity_UserID", newName: "User_UserID");
            RenameTable(name: "dbo.UserEntityGroupEntities", newName: "UserGroups");
            RenameTable(name: "dbo.MembershipEntities", newName: "Memberships");
            RenameTable(name: "dbo.UserEntities", newName: "Users");
            RenameTable(name: "dbo.GroupEntities", newName: "Groups");
            RenameTable(name: "dbo.CoachEntities", newName: "Coaches");
        }
    }
}
