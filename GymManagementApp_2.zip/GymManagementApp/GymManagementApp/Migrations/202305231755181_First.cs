﻿namespace GymManagementApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class First : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Coaches",
                c => new
                    {
                        CoachID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 30),
                        Surname = c.String(nullable: false, maxLength: 50),
                        Email = c.String(nullable: false),
                        Specialty = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.CoachID);
            
            CreateTable(
                "dbo.Groups",
                c => new
                    {
                        GroupID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 50),
                        CoachID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.GroupID)
                .ForeignKey("dbo.Coaches", t => t.CoachID, cascadeDelete: true)
                .Index(t => t.CoachID);
            
            CreateTable(
                "dbo.Users",
                c => new
                    {
                        UserID = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 30),
                        Surname = c.String(nullable: false, maxLength: 50),
                        Email = c.String(nullable: false),
                        BirthDate = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.UserID);
            
            CreateTable(
                "dbo.Memberships",
                c => new
                    {
                        MembershipId = c.Int(nullable: false, identity: true),
                        MembershipType = c.Int(nullable: false),
                        Active = c.Int(nullable: false),
                        UserID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.MembershipId)
                .ForeignKey("dbo.Users", t => t.UserID, cascadeDelete: true)
                .Index(t => t.UserID);
            
            CreateTable(
                "dbo.UserGroups",
                c => new
                    {
                        User_UserID = c.Int(nullable: false),
                        Group_GroupID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.User_UserID, t.Group_GroupID })
                .ForeignKey("dbo.Users", t => t.User_UserID, cascadeDelete: true)
                .ForeignKey("dbo.Groups", t => t.Group_GroupID, cascadeDelete: true)
                .Index(t => t.User_UserID)
                .Index(t => t.Group_GroupID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Memberships", "UserID", "dbo.Users");
            DropForeignKey("dbo.UserGroups", "Group_GroupID", "dbo.Groups");
            DropForeignKey("dbo.UserGroups", "User_UserID", "dbo.Users");
            DropForeignKey("dbo.Groups", "CoachID", "dbo.Coaches");
            DropIndex("dbo.UserGroups", new[] { "Group_GroupID" });
            DropIndex("dbo.UserGroups", new[] { "User_UserID" });
            DropIndex("dbo.Memberships", new[] { "UserID" });
            DropIndex("dbo.Groups", new[] { "CoachID" });
            DropTable("dbo.UserGroups");
            DropTable("dbo.Memberships");
            DropTable("dbo.Users");
            DropTable("dbo.Groups");
            DropTable("dbo.Coaches");
        }
    }
}
