﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using GymManagementApp.Service;

namespace GymManagementApp.Controllers
{
    public class GroupsController : Controller
    {
        private GroupService groupService = new GroupService();
        private CoachService coachService = new CoachService();
        private UserService userService = new UserService();

        public ActionResult Index()
        {
            return View(groupService.GetGroups());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GroupViewModel group = groupService.FindGroup(id);
            if (group == null)
            {
                return HttpNotFound();
            }
            return View(group);
        }

        public ActionResult Create()
        {
            ViewBag.Coaches = coachService.GetCoachesEnumerable();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(GroupViewModel group)
        {
            if (ModelState.IsValid)
            {
                groupService.SaveGroup(group);
                return RedirectToAction("Index");
            }
            ViewBag.Coaches = coachService.GetCoachesEnumerable();
            return View(group);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GroupViewModel group = groupService.FindGroup(id);
            if (group == null)
            {
                return HttpNotFound();
            }
            ViewBag.Coaches = coachService.GetCoachesEnumerable();
            return View(group);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(GroupViewModel group)
        {
            if (ModelState.IsValid)
            {
                groupService.EditGroup(group);
                return RedirectToAction("Index");
            }
            ViewBag.Coaches = coachService.GetCoachesEnumerable();
            return View(group);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GroupViewModel group = groupService.FindGroup(id);
            if (group == null)
            {
                return HttpNotFound();
            }
            return View(group);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            groupService.DeleteGroup(id);
            return RedirectToAction("Index");
        }

        public ActionResult GroupUsers(int? id)
        {
            ViewBag.id = id;
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GroupViewModel group = groupService.FindGroup(id);
            if (group == null)
            {
                return HttpNotFound();
            }
            return View(groupService.GetGroupUsers(id));
        }

        public ActionResult AddUsers(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            GroupViewModel group = groupService.FindGroup(id);
            if (group == null)
            {
                return HttpNotFound();
            }
            ViewBag.Users = userService.GetUsersEnumerable();
            return View();
        }

        [HttpPost]
        public ActionResult AddUsers()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                groupService.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
