﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace GymManagementApp.Controllers
{
    public class DocumentationController : Controller
    {
        public ActionResult Download()
        {
            string file = HostingEnvironment.MapPath("~/Docs/Goal.md");
            string contentType = "text/plain";
            return File(file, contentType, Path.GetFileName(file));
        }

    }
}