﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using GymManagementApp.Service;

namespace GymManagementApp.Controllers
{
    public class MembershipsController : Controller
    {
        private readonly MembershipService membershipService = new MembershipService();
        private readonly UserService userService = new UserService();

        public ActionResult Index()
        {
            return View(membershipService.GetMemberships());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MembershipViewModel membership = membershipService.FindMembership(id);
            membership.UserID = userService.FindUser(membership.UserID).UserID;
            if (membership == null)
            {
                return HttpNotFound();
            }
            return View(membership);
        }

        public ActionResult Create()
        {
            ViewBag.UserID = membershipService.GetUsersSelectList();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(MembershipViewModel membership)
        {
            if (ModelState.IsValid)
            {
                membershipService.SaveMembership(membership);
                return RedirectToAction("Index");
            }

            ViewBag.UserID = membershipService.GetUsersSelectList();
            return View(membership);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MembershipViewModel membership = membershipService.FindMembership(id);
            if (membership == null)
            {
                return HttpNotFound();
            }
            ViewBag.UserID = membershipService.GetUsersSelectList();
            return View(membership);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(MembershipViewModel membership)
        {
            if (ModelState.IsValid)
            {
                membershipService.EditMembership(membership);
                return RedirectToAction("Index");
            }
            ViewBag.UserID = membershipService.GetUsersSelectList();
            return View(membership);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            MembershipViewModel membership = membershipService.FindMembership(id);
            membership.UserID = userService.FindUser(membership.UserID).UserID;
            if (membership == null)
            {
                return HttpNotFound();
            }
            return View(membership);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            membershipService.DeleteMembership(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                membershipService.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
