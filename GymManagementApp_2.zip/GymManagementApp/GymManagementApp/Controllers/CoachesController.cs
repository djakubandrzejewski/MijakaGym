﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using GymManagementApp.Models;
using GymManagementApp.Models.ViewModels;
using GymManagementApp.Service;

namespace GymManagementApp.Controllers
{
    public class CoachesController : Controller
    {
        private CoachService coachService = new CoachService();

        public ActionResult Index()
        {
            return View(coachService.GetCoaches());
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CoachViewModel coach = coachService.FindCoach(id);
            if (coach == null)
            {
                return HttpNotFound();
            }
            return View(coach);
        }
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "CoachID,Name,Surname,Email,Specialty")] CoachViewModel coach)
        {
            if (ModelState.IsValid)
            {
                coachService.SaveCoach(coach);
                return RedirectToAction("Index");
            }

            return View(coach);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CoachViewModel coach = coachService.FindCoach(id);
            if (coach == null)
            {
                return HttpNotFound();
            }
            return View(coach);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "CoachID,Name,Surname,Email,Specialty")] CoachViewModel coach)
        {
            if (ModelState.IsValid)
            {
                coachService.EditCoach(coach);
                return RedirectToAction("Index");
            }
            return View(coach);
        }
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CoachViewModel coach = coachService.FindCoach(id);
            if (coach == null)
            {
                return HttpNotFound();
            }
            return View(coach);
        }


        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            coachService.DeleteCoach(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                coachService.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
