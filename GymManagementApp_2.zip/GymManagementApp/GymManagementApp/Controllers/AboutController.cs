﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;

namespace GymManagementApp.Controllers
{
    public class AboutController : Controller
    {
        public ActionResult Download()
        {
            string file = HostingEnvironment.MapPath("~/Docs/instruction.md");
            string contentType = "text/plain";
            return File(file, contentType, Path.GetFileName(file));
        }
    }
}