﻿using AutoMapper;
using GymManagementApp.Dao;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GymManagementApp.Service
{
    public class MembershipService
    {
        private readonly MembershipDao memberShipDao = new MembershipDao();
        private readonly UserService userService = new UserService();
        private IMapper MembershipMapper = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<MembershipEntity, MembershipViewModel>();
            cfg.CreateMap<MembershipViewModel, MembershipEntity>();
        }).CreateMapper();

        public List<MembershipViewModel> GetMemberships()
        {
            return memberShipDao.GetMemberships()
                .Select(membership => new
                {
                    MembershipId = membership.MembershipId,
                    UserID = membership.UserID,
                    UserFullName = userService.FindUser(membership.UserID).Name + " " + userService.FindUser(membership.UserID).Surname,
                    MembershipType = membership.MembershipType,
                    Active = membership.Active
                })
                .AsEnumerable()
                .Select(membership => new MembershipViewModel(membership.MembershipId, membership.UserID, membership.UserFullName, membership.MembershipType, membership.Active))
                .ToList();
        }

        public SelectList GetUsersSelectList()
        {
            return new SelectList(userService.GetUsers(), "UserID", "FullName");
        }

        public MembershipViewModel FindMembership(int? id)
        {
            return MembershipMapper.Map<MembershipViewModel>(memberShipDao.FindMembership(id));
        }

        public MembershipViewModel SaveMembership(MembershipViewModel membership)
        {
            return MembershipMapper.Map<MembershipViewModel>(memberShipDao.SaveMembership(MembershipMapper.Map<MembershipEntity>(membership)));
        }

        public MembershipViewModel EditMembership(MembershipViewModel membership)
        {
            return MembershipMapper.Map<MembershipViewModel>(memberShipDao.EditMembership(MembershipMapper.Map<MembershipEntity>(membership)));
        }

        public void DeleteMembership(int id)
        {
            memberShipDao.DeleteMembership(id);
        }

        public void Dispose()
        {
            memberShipDao.Dispose();
        }
    }
}