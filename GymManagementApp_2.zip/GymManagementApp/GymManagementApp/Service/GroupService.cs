﻿using AutoMapper;
using GymManagementApp.Dao;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManagementApp.Service
{
    public class GroupService
    {
        private readonly GroupDao gmd = new GroupDao();
        private readonly CoachService coachService = new CoachService();
        private IMapper GroupMapper = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<GroupEntity, GroupViewModel>();
            cfg.CreateMap<GroupViewModel, GroupEntity>();
        }).CreateMapper();

        public List<GroupViewModel> GetGroups()
        {
            return gmd.GetGroups()
                .Select(group => new
                {
                    GroupId = group.GroupID,
                    Name = group.Name,
                    CoachID = group.CoachID,
                    CoachName = coachService.FindCoach(group.CoachID).Name,
                    CoachSurname = coachService.FindCoach(group.CoachID).Surname
                })
                .AsEnumerable()
                .Select(group => new GroupViewModel(group.GroupId, group.Name, group.CoachID, group.CoachName + " " + group.CoachSurname))
                .ToList();
        }

        public List<UserViewModel> GetGroupUsers(int? id)
        {
            return gmd.FindGroup(id).Users
                .Select(user => new
                {
                    UserID = user.UserID,
                    Name = user.Name,
                    Surname = user.Surname,
                    Email = user.Email,
                    BirthDate = user.BirthDate
                })
                .AsEnumerable()
                .Select(user => new UserViewModel(user.UserID, user.Name, user.Surname, user.Email, user.BirthDate))
                .ToList(); ;
        }

        public GroupViewModel FindGroup(int? id)
        {
            return GroupMapper.Map<GroupViewModel>(gmd.FindGroup(id));
        }

        public GroupViewModel SaveGroup(GroupViewModel group)
        {
            return GroupMapper.Map<GroupViewModel>(gmd.SaveGroup(GroupMapper.Map<GroupEntity>(group)));
        }

        public GroupViewModel EditGroup(GroupViewModel group)
        {
            return GroupMapper.Map<GroupViewModel>(gmd.EditGroup(GroupMapper.Map<GroupEntity>(group)));
        }

        public void DeleteGroup(int id)
        {
            gmd.DeleteGroup(id);
        }

        public void Dispose()
        {
            gmd.Dispose();
        }
    }
}