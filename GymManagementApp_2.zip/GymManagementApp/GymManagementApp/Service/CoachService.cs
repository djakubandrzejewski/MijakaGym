﻿using AutoMapper;
using GymManagementApp.Dao;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManagementApp.Service
{
    public class CoachService
    {
        private readonly CoachDao gmd = new CoachDao();
        private IMapper CoachMapper = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<CoachEntity, CoachViewModel>();
            cfg.CreateMap<CoachViewModel, CoachEntity>();
        }).CreateMapper();

        public List<CoachViewModel> GetCoaches()
        {
            return gmd.GetCoaches()
                .Select(coach => new
                {
                    CoachId = coach.CoachID,
                    Name = coach.Name,
                    Surname = coach.Surname,
                    Email = coach.Email,
                    Specialty = coach.Specialty
                })
                .AsEnumerable()
                .Select(coach => new CoachViewModel(coach.CoachId, coach.Name, coach.Surname, coach.Email, coach.Specialty))
                .ToList();
        }

        public IEnumerable<Object> GetCoachesEnumerable()
        {
            return gmd.GetCoaches()
                .Select(coach => new
                {
                    value = coach.CoachID,
                    text = coach.Name + " " + coach.Surname
                })
                .AsEnumerable();
        }

        public CoachViewModel FindCoach(int? id)
        {
            return CoachMapper.Map<CoachViewModel>(gmd.FindCoach(id));
        }

        public CoachViewModel SaveCoach(CoachViewModel coach)
        {
            return CoachMapper.Map<CoachViewModel>(gmd.SaveCoach(CoachMapper.Map<CoachEntity>(coach)));
        }

        public CoachViewModel EditCoach(CoachViewModel coach)
        {
            return CoachMapper.Map<CoachViewModel>(gmd.EditCoach(CoachMapper.Map<CoachEntity>(coach)));
        }

        public void DeleteCoach(int id)
        {
            gmd.DeleteCoach(id);
        }

        public void Dispose()
        {
            gmd.Dispose();
        }
    }
}