﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AutoMapper;
using GymManagementApp.Dao;
using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;

namespace GymManagementApp.Service
{
    public class UserService
    {
        private readonly UserDao gmd = new UserDao();
        private IMapper UserMapper = new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<UserEntity, UserViewModel>();
            cfg.CreateMap<UserViewModel, UserEntity>();
        }).CreateMapper();

        public List<UserViewModel> GetUsers()
        {
            return gmd.GetUsers()
                .Select(user => new
                {
                    UserID = user.UserID,
                    Name = user.Name,
                    Surname = user.Surname,
                    Email = user.Email,
                    BirthDate = user.BirthDate
                })
                .AsEnumerable()
                .Select(user => new UserViewModel(user.UserID, user.Name, user.Surname, user.Email, user.BirthDate))
                .ToList();
        }

        public IEnumerable<Object> GetUsersEnumerable()
        {
            return gmd.GetUsers()
                .Select(user => new
                {
                    value = user.UserID,
                    text = user.Name + " " + user.Surname
                })
                .AsEnumerable();
        }

        public UserViewModel FindUser(int? id)
        {
            return UserMapper.Map<UserViewModel>(gmd.FindUser(id));
        }

        public UserViewModel SaveUser(UserViewModel user)
        {
            return UserMapper.Map<UserViewModel>(gmd.SaveUser(UserMapper.Map<UserEntity>(user)));
        }

        public UserViewModel EditUser(UserViewModel user)
        {
            return UserMapper.Map<UserViewModel>(gmd.EditUser(UserMapper.Map<UserEntity>(user)));
        }

        public void DeleteUser(int id)
        {
            gmd.DeleteUser(id);
        }

        public void Dispose()
        {
            gmd.Dispose();
        }
    }
}