﻿using GymManagementApp.Database;
using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models
{
    public class DatabaseContext:DbContext
    {
        public DatabaseContext() : base("GymManagementAppConnectionString")
        {
            System.Data.Entity.Database.SetInitializer(new DatabaseInitializer());
        }
        public DbSet<UserEntity> Users { get; set; }
        public DbSet<MembershipEntity> Memberships { get; set; }
        public DbSet<CoachEntity> Coaches { get; set; }
        public DbSet<GroupEntity> Groups { get; set; }
    }
}