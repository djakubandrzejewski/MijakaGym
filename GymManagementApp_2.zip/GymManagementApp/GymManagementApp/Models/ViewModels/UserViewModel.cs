﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.ViewModels
{
    public class UserViewModel
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        [Required(ErrorMessage = "type in the birth date in mm/dd/yyyy format")]
        [Display(Name = "Date of Birth")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:d}")]
        public DateTime BirthDate { get; set; }

        public UserViewModel() { }
        public UserViewModel(int UserID, string Name, string Surname, string Email, DateTime BirthDate)
        {
            this.UserID = UserID;
            this.Name = Name;
            this.Surname = Surname;
            this.FullName = Name + " " + Surname;
            this.Email = Email;
            this.BirthDate = BirthDate;
        }
    }
}