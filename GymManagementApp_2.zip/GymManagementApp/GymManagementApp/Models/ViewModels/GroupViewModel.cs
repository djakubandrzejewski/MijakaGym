﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.ViewModels
{
    public class GroupViewModel
    {
        public int GroupID { get; set; }
        public string Name { get; set; }
        public int CoachID { get; set; }
        public string CoachFullName { get; set; }
        public virtual ICollection<UserViewModel> Users { get; set; }

        public GroupViewModel() { }
        public GroupViewModel(int GroupID, string Name, int CoachID, string CoachFullName)
        {
            this.GroupID = GroupID;
            this.Name = Name;
            this.CoachID = CoachID;
            this.CoachFullName = CoachFullName;
        }
    }
}