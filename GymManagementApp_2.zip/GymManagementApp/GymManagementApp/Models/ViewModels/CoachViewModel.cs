﻿using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.ViewModels
{
    public class CoachViewModel
    {
        public int CoachID { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public Specialty Specialty { get; set; }
        public CoachViewModel() { }
        public CoachViewModel(int CoachID, string Name, string Surname, string Email, Specialty Specialty)
        {
            this.CoachID = CoachID;
            this.Name = Name;
            this.Surname = Surname;
            this.Email = Email;
            this.Specialty = Specialty;
        }
        public override string ToString()
        {
            return this.Name + " " + this.Surname;
        }
    }
}