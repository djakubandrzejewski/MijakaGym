﻿using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.ViewModels
{
    public class MembershipViewModel
    {
        public int MembershipID { get; set; }
        public int UserID { get; set; }
        public string UserFullName { get; set; }
        public MembershipType MembershipType { get; set; }
        public Active Active { get; set; }
        public MembershipViewModel() { }
        public MembershipViewModel(int MembershipID, int UserID, string UserFullName, MembershipType membershipType, Active active)
        {
            this.MembershipID = MembershipID;
            this.UserID = UserID;
            this.UserFullName = UserFullName;
            this.MembershipType = membershipType;
            this.Active = active;
        }
    }
}