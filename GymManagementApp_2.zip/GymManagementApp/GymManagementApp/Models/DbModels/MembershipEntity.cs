﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.Design;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.dbModels
{
    public enum MembershipType { junior, standard, premium }
    public enum Active { active, inactive}
    public class MembershipEntity
    {
        [Key]
        public int MembershipId { get; set; }
        [Required]
        public MembershipType MembershipType { get; set; }
        public Active Active { get; set; }
        [ForeignKey("User")]
        public int UserID { get; set; }
        public UserEntity User { get; set; }
        public MembershipEntity() { }
        public MembershipEntity(int MembershipId, MembershipType MembershipType, Active Active, int UserID, UserEntity User)
        {
            this.MembershipId = MembershipId;
            this.MembershipType = MembershipType;
            this.UserID = UserID;
            this.User = User;
        }
    }
}