﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.dbModels
{
    public enum Specialty { yoga, calisthenics, powerlifting }
    public class CoachEntity
    {
        [Key]
        public int CoachID { get; set; }
        [Required,StringLength(30)]
        public string Name { get; set; }
        [Required,StringLength(50)]
        public string Surname { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public Specialty Specialty { get; set; }
        public ICollection<GroupEntity> Groups { get; set; }
        public CoachEntity() { }
        public CoachEntity(int CoachID, string Name, string Surname, string Email, Specialty Specialty)
        {
            this.CoachID = CoachID;
            this.Name = Name;
            this.Surname = Surname;
            this.Email = Email;
            this.Specialty = Specialty;
        }
    }
}