﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.dbModels
{
    public class UserEntity
    {
        [Key]
        public int UserID { get; set; }
        [Required,StringLength(30)]
        public string Name { get; set; }
        [Required,StringLength(50)]
        public string Surname { get; set; }
        [Required]
        public string Email { get; set; }
        public DateTime BirthDate { get; set; }
        public virtual ICollection<MembershipEntity> Memberships { get; set; }
        public virtual ICollection<GroupEntity> Groups { get; set; }
        public string DisplayFull => $"{Name} {Surname}, {Email}, {BirthDate:dd/MM/yyyy}";
        public UserEntity() { }
        public UserEntity(int UserID, string Name, string Surname, string Email, DateTime BirthDate)
        {
            this.UserID = UserID;
            this.Name = Name;
            this.Surname = Surname;
            this.Email = Email;
            this.BirthDate = BirthDate;
        }
    }
}