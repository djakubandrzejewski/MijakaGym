﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace GymManagementApp.Models.dbModels
{
    public class GroupEntity
    {
        [Key]
        public int GroupID { get; set; }
        [Required,StringLength(50)]
        public string Name { get; set; }
        [ForeignKey("Coach")]
        public int CoachID { get; set; }
        public CoachEntity Coach { get; set; }
        public virtual ICollection<UserEntity> Users { get; set; }
        public GroupEntity() { }
        public GroupEntity(int GroupID, string Name, int CoachID, CoachEntity Coach)
        {
            this.GroupID = GroupID;
            this.Name = Name;
            this.CoachID = CoachID;
            this.Coach = Coach;
        }
    }
}