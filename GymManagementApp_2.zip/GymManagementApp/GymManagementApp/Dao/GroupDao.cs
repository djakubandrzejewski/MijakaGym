﻿using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Dao
{
    public class GroupDao
    {
        private readonly DatabaseContext db = new DatabaseContext();

        public List<GroupEntity> GetGroups()
        {
            return db.Groups.ToList();
        }

        public GroupEntity FindGroup(int? id)
        {
            return db.Groups.Find(id);
        }

        public GroupEntity SaveGroup(GroupEntity coach)
        {
            using (DatabaseContext db = new DatabaseContext())
            {
                GroupEntity savedGroup = db.Groups.Add(coach);
                db.SaveChanges();
                return savedGroup;
            }

        }

        public GroupEntity EditGroup(GroupEntity coach)
        {
            db.Entry(coach).State = EntityState.Modified;
            db.SaveChanges();
            return db.Groups.Find(coach.GroupID);
        }

        public void DeleteGroup(int id)
        {
            GroupEntity group = db.Groups.Find(id);
            db.Groups.Remove(group);
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}