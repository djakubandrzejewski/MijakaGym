﻿using AutoMapper;
using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using GymManagementApp.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Dao
{
    public class UserDao
    {
        private readonly DatabaseContext db = new DatabaseContext();

        public List<UserEntity> GetUsers()
        {
            return db.Users.ToList();
        }

        public UserEntity FindUser(int? id)
        {
            return db.Users.Find(id);
        }

        public UserEntity SaveUser(UserEntity user)
        {
            using (DatabaseContext db = new DatabaseContext())
            {
                UserEntity savedUser = db.Users.Add(user);
                db.SaveChanges();
                return savedUser;
            }

        }

        public UserEntity EditUser(UserEntity user)
        {
            db.Entry(user).State = EntityState.Modified;
            db.SaveChanges();
            return db.Users.Find(user.UserID);
        }

        public void DeleteUser(int id)
        {
            UserEntity user = db.Users.Find(id);
            db.Users.Remove(user);
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}