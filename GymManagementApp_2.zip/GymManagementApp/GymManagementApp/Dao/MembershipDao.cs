﻿using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Dao
{
    public class MembershipDao
    {
        private readonly DatabaseContext db = new DatabaseContext();

        public List<MembershipEntity> GetMemberships()
        {
            return db.Memberships.Include(m => m.User).ToList();
        }

        public MembershipEntity FindMembership(int? id)
        {
            return db.Memberships.Find(id);
        }

        public MembershipEntity SaveMembership(MembershipEntity membership)
        {
            using (DatabaseContext db = new DatabaseContext())
            {
                MembershipEntity savedMembership = db.Memberships.Add(membership);
                savedMembership.User = db.Users.Find(membership.UserID);
                db.SaveChanges();
                return savedMembership;
            }

        }

        public MembershipEntity EditMembership(MembershipEntity membership)
        {
            db.Entry(membership).State = EntityState.Modified;
            membership.User = db.Users.Find(membership.UserID);
            db.SaveChanges();
            return db.Memberships.Find(membership.MembershipId);
        }

        public void DeleteMembership(int id)
        {
            MembershipEntity membership = db.Memberships.Find(id);
            db.Memberships.Remove(membership);
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}