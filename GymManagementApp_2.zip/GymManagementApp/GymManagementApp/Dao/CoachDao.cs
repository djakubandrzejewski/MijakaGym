﻿using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Dao
{
    public class CoachDao
    {
        private readonly DatabaseContext db = new DatabaseContext();

        public List<CoachEntity> GetCoaches()
        {
            return db.Coaches.ToList();
        }

        public CoachEntity FindCoach(int? id)
        {
            return db.Coaches.Find(id);
        }

        public CoachEntity SaveCoach(CoachEntity coach)
        {
            using (DatabaseContext db = new DatabaseContext())
            {
                CoachEntity savedCoach = db.Coaches.Add(coach);
                db.SaveChanges();
                return savedCoach;
            }

        }

        public CoachEntity EditCoach(CoachEntity coach)
        {
            db.Entry(coach).State = EntityState.Modified;
            db.SaveChanges();
            return db.Coaches.Find(coach.CoachID);
        }

        public void DeleteCoach(int id)
        {
            CoachEntity coach = db.Coaches.Find(id);
            db.Coaches.Remove(coach);
            db.SaveChanges();
        }

        public void Dispose()
        {
            db.Dispose();
        }
    }
}