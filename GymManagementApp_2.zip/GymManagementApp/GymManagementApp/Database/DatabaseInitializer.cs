﻿using AutoMapper;
using GymManagementApp.Models;
using GymManagementApp.Models.dbModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace GymManagementApp.Database
{
    public class DatabaseInitializer : DropCreateDatabaseAlways<DatabaseContext>
    {

        private static List<UserEntity> initUsers = new List<UserEntity>() {
            new UserEntity(1, "Izabela", "Złotopiórka", "izlotop@onet.pl", new DateTime(2000, 5, 12)),
            new UserEntity(2, "Marian", "Kaczor", "mkaczor@outlook.com", new DateTime(2002, 12, 30))
            };

        private static List<CoachEntity> initCoaches = new List<CoachEntity>() {
            new CoachEntity(1, "Marcin", "Stopaczewiczowski", "mstopacz@student.agh.edu.pl", Specialty.calisthenics),
            new CoachEntity(2, "Agata", "Maryniuk", "maryna@wp.pl", Specialty.yoga)
        };

        private static List<GroupEntity> initGroups = new List<GroupEntity>() {
            new GroupEntity(1, "Pandy", 1, initCoaches[0]),
            new GroupEntity(2, "Kwiaty lotosu", 2, initCoaches[1])
        };

        private static List<MembershipEntity> initMemberships = new List<MembershipEntity>() {
            new MembershipEntity(1, MembershipType.junior, Active.active, 1, initUsers[0]),
            new MembershipEntity(2, MembershipType.premium, Active.active, 2, initUsers[1])
        };

        protected override void Seed(DatabaseContext db)
        {
            db.Users.AddRange(initUsers);
            db.Coaches.AddRange(initCoaches);
            db.Groups.AddRange(initGroups);
            db.Memberships.AddRange(initMemberships);

            base.Seed(db);
        }
    }
}